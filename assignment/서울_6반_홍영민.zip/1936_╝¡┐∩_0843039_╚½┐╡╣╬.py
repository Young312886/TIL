a, b = map(int, input().split())
c = a-b
if c == 1 or c == -2:
    result = "A"
else :
    result = "B"
print(result)