package study.JavaStudy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaStudyApplicationTests {

	@Test
	void contextLoads() {
	}

}
